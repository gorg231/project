import React from 'react';
import './Game1.css';

function Game1(props) {
    return (
        <>
        
        </>
    );
}


export default Game1;