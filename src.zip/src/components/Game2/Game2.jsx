import React from 'react';
import './Game2.css';

function Game2(props) {
    return (
        <>
        
        </>
    );
}


export default Game2;