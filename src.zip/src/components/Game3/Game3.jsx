import React from 'react';
import './Game3.css';

function Game3(props) {
    return (
        <>
        
        </>
    );
}


export default Game3;